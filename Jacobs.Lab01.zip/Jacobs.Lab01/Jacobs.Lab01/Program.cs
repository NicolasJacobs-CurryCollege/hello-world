﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");

namespace CardsAfterShuffle
{
    public class TheShuffledDeck
    {
        public TheShuffledDeck()
        {
            string[] theDeck = null;
            string[] theShuffledDeck = null;

            theDeck = OneDeck();
            ShowDeck(theDeck);

            theShuffledDeck = ShuffledDeck(theDeck);

            ShowDeck(theShuffledDeck);
        }

        // Initialize the deck of cards
        public string[] OneDeck()
        {
            string[] theDeck = InitializeDeck();

            // Assign numbers to cards
            theDeck = AssignNumbersToCards(theDeck);

            // Assign pictures to cards
            theDeck = AssignPicturesToCards(theDeck);

            // Assign suits to cards
            theDeck = AssignSuitsToCards(theDeck);

            return theDeck;
        }

        // Initializes the deck of cards
        public string[] InitializeDeck()
        {
            return new string[52];
        }

        // Assigns numbers to cards in the deck
        public string[] AssignNumbersToCards(string[] theDeck)
        {
            for (int cardIndex = 0, number = 0; cardIndex < theDeck.Length; cardIndex++, number++)
            {
                if (number == 13)
                {
                    number = 0;
                }
                theDeck[cardIndex] = number.ToString();
            }
            return theDeck;
        }

        // Assigns suits to the cards in the deck
        public string[] AssignSuitsToCards(string[] theDeck)
        {
            for (int cardIndex = 0; cardIndex < theDeck.Length; cardIndex++)
            {
                switch (cardIndex / 13)
                {
                    case 0:
                        theDeck[cardIndex] += " clubs";
                        break;
                    case 1:
                        theDeck[cardIndex] += " diamonds";
                        break;
                    case 2:
                        theDeck[cardIndex] += " hearts";
                        break;
                    default:
                        theDeck[cardIndex] += " spades";
                        break;
                }
            }
            return theDeck;
        }

        // Assigns pictures (face cards) to the cards in the deck
        public string[] AssignPicturesToCards(string[] theDeck)
        {
            for (int cardIndex = 0; cardIndex < theDeck.Length; cardIndex++)
            {
                switch (int.Parse(theDeck[cardIndex]))
                {
                    case 0:
                        theDeck[cardIndex] = "ace";
                        break;
                    case 10:
                        theDeck[cardIndex] = "jack";
                        break;
                    case 11:
                        theDeck[cardIndex] = "queen";
                        break;
                    case 12:
                        theDeck[cardIndex] = "king";
                        break;
                    default:
                        theDeck[cardIndex] = (int.Parse(theDeck[cardIndex]) + 1).ToString();
                        break;
                }
            }
            return theDeck;
        }

        // Displays the deck of cards
        public void ShowDeck(string[] theDeck)
        {
            string outputString = "";
            for (int cardIndex = 0; cardIndex < theDeck.Length; cardIndex++)
            {
                if (cardIndex % 13 == 0 && cardIndex != 0)
                {
                    outputString += "\n";
                }
                outputString += theDeck[cardIndex] + ", ";
            }
            MessageBox.Show(outputString);
        }

        public int ObtainRandomNumber(int maxValue)
        {
            Random random = new Random();
            return random.Next(maxValue);
        }

        public string[] InitializeShuffleTheDeck(string[] theDeck)
        {
            return new string[theDeck.Length];
        }

        public string[] MakeDisposableDeck(string[] theDeck)
        {
            string[] disposableDeck = new string[theDeck.Length];
            Array.Copy(theDeck, disposableDeck, theDeck.Length);
            return disposableDeck;
        }

        public string[] ShuffledDeck(string[] theDeck)
        {
            int eleNum;
            string[] theShuffledDeck = InitializeShuffleTheDeck(theDeck);

            string[] disposableDeck = MakeDisposableDeck(theDeck);

            for (int n = 0; n < theDeck.Length; n++)
            {
                eleNum = ObtainRandomNumber(disposableDeck.Length);

                while (disposableDeck[eleNum].Equals("-1", StringComparison.OrdinalIgnoreCase))
                {
                    eleNum++;
                    if (eleNum == disposableDeck.Length)
                    {
                        eleNum = 0;
                    }
                }

                theShuffledDeck[n] = disposableDeck[eleNum];
                disposableDeck[eleNum] = "-1";
            }

            return theShuffledDeck;
        }
    }
}
