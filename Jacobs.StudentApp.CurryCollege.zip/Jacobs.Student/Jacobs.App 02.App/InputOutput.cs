﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student
{
    public class InputOutput
    {
        public InputOutput() { }

        public void DisplayMessage(String message)
        {
            Console.WriteLine(message);
        }

        public String GetInputFromUser(String prompt)
        {
            Console.Write(prompt + "  ");
            return Console.ReadLine();
        }
    }
}