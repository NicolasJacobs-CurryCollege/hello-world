﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student
{
    public class OneCourse
    {
        // Attributes
        private string coursePrefix = "";
        private int courseNumber = -1;
        private string courseName = "";
        private int numRegisteredStudents = -1;
        private OneStudent[] enrolledStudents;

        // Constructor
        public OneCourse() { }

        // Behaviors
        public bool SetCoursePrefix(string prefix)
        {
            if (prefix == null || prefix.Length == 0)
                return false;

            coursePrefix = prefix;
            return true;
        }

        public string GetCoursePrefix()
        {
            return coursePrefix;
        }

        public bool SetCourseNumber(string number)
        {
            if (number == null || number.Length == 0 || !CanBePositiveInteger(number))
                return false;

            courseNumber = Convert.ToInt32(number);
            return true;
        }

        public string GetCourseNumber()
        {
            return courseNumber.ToString();
        }

        public bool SetCourseName(string name)
        {
            if (name == null || name.Length == 0)
                return false;

            courseName = name;
            return true;
        }

        public string GetCourseName()
        {
            return courseName;
        }

        public bool SetNumRegisteredStudents(string count)
        {
            if (count == null || count.Length == 0 || !CanBePositiveInteger(count))
                return false;

            numRegisteredStudents = Convert.ToInt32(count);
            return true;
        }

        public string GetNumRegisteredStudents()
        {
            return numRegisteredStudents.ToString();
        }

        public bool SetEnrolledStudents(OneStudent[] students)
        {
            if (students == null || students.Length == 0)
                return false;

            enrolledStudents = students;
            return true;
        }

        public OneStudent[] GetEnrolledStudents()
        {
            return enrolledStudents;
        }

        public bool AddOneStudent()
        {
            string temp;

            if (enrolledStudents == null)
            {
                if (numRegisteredStudents == -1)
                    return false;

                enrolledStudents = new OneStudent[numRegisteredStudents];
            }

            int n = 0;
            while (enrolledStudents[n] != null)
            {
                n++;
                if (n == numRegisteredStudents)
                    return false;
            }

            enrolledStudents[n] = new OneStudent();

            do
            {
                temp = ObtainInfoFromUser("What is this student's name?");
            } while (temp == null || temp.Length == 0);
            enrolledStudents[n].SetName(temp);

            // Similarly for other student attributes...

            return true;
        }

        // Other methods...

        private bool CanBePositiveInteger(string str)
        {
            try
            {
                if (Convert.ToInt32(str) > -1)
                    return true;
                return false;
            }
            catch
            {
                return false;
            }
        }

        // Other methods...

        private string ObtainInfoFromUser(string prompt)
        {
            // Simulated method to obtain input from user
            return prompt; // For illustration purposes, just returning the prompt itself
        }
    }
}

