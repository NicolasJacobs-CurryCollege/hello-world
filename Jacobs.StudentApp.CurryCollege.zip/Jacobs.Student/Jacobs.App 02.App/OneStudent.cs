﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student
{
    public class OneStudent
    {
        // Member variables
        private string studentName = null;
        private int studentAge = -1;
        private double studentGPA = -1;
        private char studentGender;
        private string studentID = null;
        private string accessCodeForSet = "pw";
        private string accessCodeForGet = "abcd";

        // Constructor
        public OneStudent() { } // Default constructor

        // Methods
        public bool SetName(string name)
        {
            if (name == null || name.Length == 0)
                return false;

            studentName = name;
            return true;
        }

        public string GetName()
        {
            if (studentName == null)
                return "Name not set";

            return studentName;
        }

        public bool SetAge(string ageStr)
        {
            if (ageStr == null || ageStr.Length == 0)
                return false;

            if (IsValidPositiveInteger(ageStr))
            {
                studentAge = Convert.ToInt32(ageStr);
                return true;
            }

            return false;
        }

        public string GetAge()
        {
            if (studentAge == -1)
                return "Age not set";

            return studentAge.ToString();
        }

        public bool SetGPA(string gpaStr)
        {
            if (gpaStr == null || gpaStr.Length == 0)
                return false;

            if (IsValidPositiveDouble(gpaStr))
            {
                studentGPA = Convert.ToDouble(gpaStr);
                return true;
            }

            return false;
        }

        public string GetGPA()
        {
            if (studentGPA == -1)
                return "GPA not set";

            return studentGPA.ToString();
        }

        public bool SetGender(string genderStr)
        {
            if (genderStr == null || genderStr.Length == 0)
                return false;

            switch (genderStr.ToLower()[0])
            {
                case 'm':
                    studentGender = 'm';
                    break;
                case 'f':
                    studentGender = 'f';
                    break;
                case 'o':
                    studentGender = 'o';
                    break;
                case 'p':
                    studentGender = 'p';
                    break;
                default:
                    return false;
            }
            return true;
        }

        public string GetGender()
        {
            switch (studentGender)
            {
                case 'm':
                    return "Male";
                case 'f':
                    return "Female";
                case 'o':
                    return "Other";
                case 'p':
                    return "Prefer not to say";
                default:
                    return "Gender not set";
            }
        }

        public bool SetStudentID(string id, string accessCode)
        {
            if (accessCode == accessCodeForSet)
            {
                if (id == null || id.Length == 0)
                    return false;

                studentID = id;
                return true;
            }

            return false;
        }

        public string GetStudentID(string accessCode)
        {
            if (accessCode == accessCodeForGet)
            {
                if (studentName == null)
                    return "Student ID not available";

                return studentID;
            }

            return "Unauthorized access";
        }

        private bool IsValidPositiveInteger(string str)
        {
            try
            {
                if (Convert.ToInt32(str) > -1)
                    return true;
                return false;
            }
            catch
            {
                return false;
            }
        }

        private bool IsValidPositiveDouble(string str)
        {
            try
            {
                if (Convert.ToDouble(str) > -1)
                    return true;
                return false;
            }
            catch
            {
                return false;
            }
        }
    }
}
