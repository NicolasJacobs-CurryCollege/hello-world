﻿// See https://aka.ms/new-console-template for more information
using Student;

internal class Program
{
    private static void Main(string[] args)
    {
        Console.WriteLine("Hello, World!");

new CompSciDept();
    }
}