﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student
{
    public class CompSciDept
    {
        private OneCourse[] courses;
        private int courseCount = 2;

        public CompSciDept() { }

        private void AddCourse()
        {

        }
    }
}
