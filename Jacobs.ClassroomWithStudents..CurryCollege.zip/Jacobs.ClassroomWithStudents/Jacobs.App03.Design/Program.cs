﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");

namespace Student
{
    // Date Class
    public class Date
    {
        private int day;
        private int month;
        private int year;

        // Constructor
        public Date(int d, int m, int y)
        {
            day = d;
            month = m;
            year = y;
        }

        // Behaviors

        // Method to get the day
        public int getDay()
        {
            return day;
        }

        // Method to get the month
        public int getMonth()
        {
            return month;
        }

        // Method to get the year
        public int getYear()
        {
            return year;
        }
    }

    // Student Class
    public class OneStudent
    {
        // Attributes
        private string name = null;
        private Date birthDate;
        private char gender;
        private string sSNumber = null;
        private string ssPasswordSet = "pw";
        private string ssPasswordGet = "abcd";

        // Constructor
        public OneStudent() { } // Default constructor

        // Behaviors

        // Method to set the name of the student
        public bool setName(string s)
        {
            if (s == null || s.Length == 0)
                return false;

            name = s;
            return true;
        }

        // Method to get the name of the student
        public string getName()
        {
            if (name == null)
                return "name not initialized";

            return name;
        }

        // Method to set the birth date of the student
        public void setBirthDate(Date date)
        {
            birthDate = date;
        }

        // Method to get the birth date of the student
        public Date getBirthDate()
        {
            return birthDate;
        }

        // Method to set the gender of the student
        public bool setGender(string s)
        {
            if (s == null || s.Length == 0)
                return false;

            switch (s.ToLower()[0])
            {
                case 'm':
                    gender = 'm';
                    break;
                case 'f':
                    gender = 'f';
                    break;
                case 't':
                    gender = 't';
                    break;
                case 'p':
                    gender = 'p';
                    break;
                default:
                    return false;
            }
            return true;
        }

        // Method to get the gender of the student
        public string getGender()
        {
            switch (gender)
            {
                case 'm':
                    return "male";
                case 'f':
                    return "female";
                case 't':
                    return "trans";
                case 'p':
                    return "prefer not to say";
                default:
                    return "gender not initialized";
            }
        }

        // Method to set the social security number of the student
        public bool setSSNumber(string s, string ssPassword)
        {
            if (ssPassword == ssPasswordSet)
            {
                if (s == null || s.Length == 0)
                    return false;

                sSNumber = s;
                return true;
            }

            return false;
        }

        // Method to get the social security number of the student
        public string getSSNumber(string ssPassword)
        {
            if (ssPassword == ssPasswordGet)
            {
                if (name == null)
                    return "social security number not initialized";

                return sSNumber;
            }

            return "you are not authorized to see this item";
        }
    }

    // Classroom Class
    public class Classroom
    {
        private OneStudent student;

        // Constructor
        public Classroom() { } // Default constructor

        // Behaviors

        // Method to initialize student attributes
        public void initializeStudent(string name, Date birthDate, string gender, string sSNumber, string ssPassword)
        {
            student = new OneStudent();
            student.setName(name);
            student.setBirthDate(birthDate);
            student.setGender(gender);
            student.setSSNumber(sSNumber, ssPassword);
        }
    }
}
