﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");


namespace Student
{
    public class OneStudent
    {
        // Attributes
        private String name = null;
        private int age = -1;
        private double gpa = -1;
        private char gender;
        private String sSNumber = null;
        private String ssPasswordSet = "pw";
        private String ssPasswordGet = "abcd";

        // Constructor
        public OneStudent() { } // Default constructor

        // Behaviors

        // Method to set the name of the student
        public bool setName(String s)
        {
            if (s == null || s.Length == 0)
                return false;

            name = s;
            return true;
        }

        // Method to get the name of the student
        public String getName()
        {
            if (name == null)
                return "name not initialized";

            return name;
        }

        // Method to set the age of the student
        public bool setAge(String s)
        {
            if (s == null || s.Length == 0)
                return false;

            if (canBePositiveInt(s))
            {
                age = Convert.ToInt32(s);
                return true;
            }

            return false;
        }

        // Method to get the age of the student
        public String getAge()
        {
            if (age == -1)
                return "age not initialized";

            return age.ToString();
        }

        // Method to set the GPA of the student
        public bool setGPA(String s)
        {
            if (s == null || s.Length == 0)
                return false;

            if (canBePositiveDouble(s))
            {
                age = Convert.ToInt32(s); // Shouldn't this be gpa instead of age?
                return true;
            }

            return false;
        }

        // Method to get the GPA of the student
        public String getGPA()
        {
            if (gpa == -1)
                return "gpa not initialized";

            return gpa.ToString();
        }

        // Method to set the gender of the student
        public bool setGender(String s)
        {
            if (s == null || s.Length == 0)
                return false;

            switch (s.ToLower()[0])
            {
                case 'm':
                    gender = 'm';
                    break;
                case 'f':
                    gender = 'f';
                    break;
                case 't':
                    gender = 't';
                    break;
                case 'p':
                    gender = 'p';
                    break;
                default:
                    return false;
            }
            return true;
        }

        // Method to get the gender of the student
        public String getGender()
        {
            switch (gender)
            {
                case 'm':
                    return "male";
                case 'f':
                    return "female";
                case 't':
                    return "trans";
                case 'p':
                    return "prefer not to say";
                default:
                    return "gender not initialized";
            }
        }

        // Method to set the social security number of the student
        public bool setSSNumber(String s, String ssPassword)
        {
            if (ssPassword == ssPasswordSet)
            {
                if (s == null || s.Length == 0)
                    return false;

                sSNumber = s;
                return true;
            }

            return false;
        }

        // Method to get the social security number of the student
        public String getSSNumber(String ssPassword)
        {
            if (ssPassword == ssPasswordGet)
            {
                if (name == null)
                    return "social security number not initialized";

                return sSNumber;
            }

            return "you are not authorized to see this item";
        }

        // Method to check if a string can be converted to a positive integer
        private bool canBePositiveInt(String s)
        {
            try
            {
                if (Convert.ToInt32(s) > -1)
                    return true;
                return false;
            }
            catch
            {
                return false;
            }
        }

        // Method to check if a string can be converted to a positive double
        private bool canBePositiveDouble(String s)
        {
            try
            {
                if (Convert.ToDouble(s) > -1)
                    return true;
                return false; // Negative number
            }
            catch
            {
                return false; // s cannot be converted into a double
            }
        }
    }
}

