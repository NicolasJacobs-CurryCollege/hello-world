﻿namespace CohenSharon.Capstone.StubsAndUI_GoFish
{
    partial class Player2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Player2));
            this.lstHandPlayer2 = new System.Windows.Forms.ListBox();
            this.lblPlayerName2 = new System.Windows.Forms.Label();
            this.lblCountBooks = new System.Windows.Forms.Label();
            this.lblNumberOfBooks = new System.Windows.Forms.Label();
            this.btnLoadHand = new System.Windows.Forms.Button();
            this.btnEndTurn1 = new System.Windows.Forms.Button();
            this.lblGoFish = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lstHandPlayer2
            // 
            this.lstHandPlayer2.FormattingEnabled = true;
            this.lstHandPlayer2.HorizontalScrollbar = true;
            this.lstHandPlayer2.ItemHeight = 16;
            this.lstHandPlayer2.Items.AddRange(new object[] {
            "Card1",
            "card2",
            "card3",
            "card4",
            "card5",
            "card6"});
            this.lstHandPlayer2.Location = new System.Drawing.Point(12, 56);
            this.lstHandPlayer2.Name = "lstHandPlayer2";
            this.lstHandPlayer2.Size = new System.Drawing.Size(138, 244);
            this.lstHandPlayer2.TabIndex = 11;
            // 
            // lblPlayerName2
            // 
            this.lblPlayerName2.AutoSize = true;
            this.lblPlayerName2.BackColor = System.Drawing.Color.Transparent;
            this.lblPlayerName2.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlayerName2.ForeColor = System.Drawing.Color.Orange;
            this.lblPlayerName2.Location = new System.Drawing.Point(241, 9);
            this.lblPlayerName2.Name = "lblPlayerName2";
            this.lblPlayerName2.Size = new System.Drawing.Size(314, 58);
            this.lblPlayerName2.TabIndex = 6;
            this.lblPlayerName2.Text = "Player Name";
            // 
            // lblCountBooks
            // 
            this.lblCountBooks.BackColor = System.Drawing.Color.Transparent;
            this.lblCountBooks.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCountBooks.ForeColor = System.Drawing.Color.DarkOrange;
            this.lblCountBooks.Location = new System.Drawing.Point(575, 286);
            this.lblCountBooks.Name = "lblCountBooks";
            this.lblCountBooks.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblCountBooks.Size = new System.Drawing.Size(70, 41);
            this.lblCountBooks.TabIndex = 17;
            this.lblCountBooks.Text = "0";
            this.lblCountBooks.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblCountBooks.Click += new System.EventHandler(this.lblCountBooks_Click);
            // 
            // lblNumberOfBooks
            // 
            this.lblNumberOfBooks.BackColor = System.Drawing.Color.Transparent;
            this.lblNumberOfBooks.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumberOfBooks.ForeColor = System.Drawing.Color.Orange;
            this.lblNumberOfBooks.Location = new System.Drawing.Point(449, 230);
            this.lblNumberOfBooks.Name = "lblNumberOfBooks";
            this.lblNumberOfBooks.Size = new System.Drawing.Size(317, 56);
            this.lblNumberOfBooks.TabIndex = 16;
            this.lblNumberOfBooks.Text = "Number Of Books";
            this.lblNumberOfBooks.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnLoadHand
            // 
            this.btnLoadHand.BackColor = System.Drawing.Color.Orange;
            this.btnLoadHand.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoadHand.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnLoadHand.Location = new System.Drawing.Point(286, 262);
            this.btnLoadHand.Name = "btnLoadHand";
            this.btnLoadHand.Size = new System.Drawing.Size(75, 59);
            this.btnLoadHand.TabIndex = 20;
            this.btnLoadHand.Text = "Load Hand";
            this.btnLoadHand.UseVisualStyleBackColor = false;
            this.btnLoadHand.Click += new System.EventHandler(this.btnLoadHand_Click);
            // 
            // btnEndTurn1
            // 
            this.btnEndTurn1.BackColor = System.Drawing.Color.Orange;
            this.btnEndTurn1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEndTurn1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnEndTurn1.Location = new System.Drawing.Point(185, 262);
            this.btnEndTurn1.Name = "btnEndTurn1";
            this.btnEndTurn1.Size = new System.Drawing.Size(82, 59);
            this.btnEndTurn1.TabIndex = 19;
            this.btnEndTurn1.Text = "End Turn";
            this.btnEndTurn1.UseVisualStyleBackColor = false;
            this.btnEndTurn1.Click += new System.EventHandler(this.btnEndTurn1_Click);
            // 
            // lblGoFish
            // 
            this.lblGoFish.BackColor = System.Drawing.Color.Orange;
            this.lblGoFish.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGoFish.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblGoFish.Location = new System.Drawing.Point(343, 83);
            this.lblGoFish.Name = "lblGoFish";
            this.lblGoFish.Size = new System.Drawing.Size(102, 52);
            this.lblGoFish.TabIndex = 21;
            this.lblGoFish.Text = "Go Fish";
            this.lblGoFish.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Player2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(801, 355);
            this.Controls.Add(this.lblGoFish);
            this.Controls.Add(this.btnLoadHand);
            this.Controls.Add(this.btnEndTurn1);
            this.Controls.Add(this.lblCountBooks);
            this.Controls.Add(this.lblNumberOfBooks);
            this.Controls.Add(this.lstHandPlayer2);
            this.Controls.Add(this.lblPlayerName2);
            this.Name = "Player2";
            this.Text = "2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lstHandPlayer2;
        private System.Windows.Forms.Label lblPlayerName2;
        private System.Windows.Forms.Label lblCountBooks;
        private System.Windows.Forms.Label lblNumberOfBooks;
        private System.Windows.Forms.Button btnLoadHand;
        private System.Windows.Forms.Button btnEndTurn1;
        private System.Windows.Forms.Label lblGoFish;
    }
}