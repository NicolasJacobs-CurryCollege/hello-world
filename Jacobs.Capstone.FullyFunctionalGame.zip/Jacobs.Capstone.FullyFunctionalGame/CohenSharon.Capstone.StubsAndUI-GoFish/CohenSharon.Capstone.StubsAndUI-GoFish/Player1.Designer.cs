﻿namespace CohenSharon.Capstone.StubsAndUI_GoFish
{
    partial class Player1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Player1));
            this.lblPlayerName1 = new System.Windows.Forms.Label();
            this.btnEndTurn1 = new System.Windows.Forms.Button();
            this.lstHandPlayer1 = new System.Windows.Forms.ListBox();
            this.lblGoFish = new System.Windows.Forms.Label();
            this.lblCountBooks = new System.Windows.Forms.Label();
            this.lblNumberOfBooks = new System.Windows.Forms.Label();
            this.btnLoadHand = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblPlayerName1
            // 
            this.lblPlayerName1.AutoSize = true;
            this.lblPlayerName1.BackColor = System.Drawing.Color.Transparent;
            this.lblPlayerName1.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlayerName1.ForeColor = System.Drawing.Color.DarkOrange;
            this.lblPlayerName1.Location = new System.Drawing.Point(241, 23);
            this.lblPlayerName1.Name = "lblPlayerName1";
            this.lblPlayerName1.Size = new System.Drawing.Size(314, 58);
            this.lblPlayerName1.TabIndex = 0;
            this.lblPlayerName1.Text = "Player Name";
            // 
            // btnEndTurn1
            // 
            this.btnEndTurn1.BackColor = System.Drawing.Color.Orange;
            this.btnEndTurn1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEndTurn1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnEndTurn1.Location = new System.Drawing.Point(179, 265);
            this.btnEndTurn1.Name = "btnEndTurn1";
            this.btnEndTurn1.Size = new System.Drawing.Size(82, 59);
            this.btnEndTurn1.TabIndex = 3;
            this.btnEndTurn1.Text = "End Turn";
            this.btnEndTurn1.UseVisualStyleBackColor = false;
            this.btnEndTurn1.Click += new System.EventHandler(this.btnEndTurn1_Click);
            // 
            // lstHandPlayer1
            // 
            this.lstHandPlayer1.FormattingEnabled = true;
            this.lstHandPlayer1.HorizontalScrollbar = true;
            this.lstHandPlayer1.ItemHeight = 16;
            this.lstHandPlayer1.Location = new System.Drawing.Point(12, 23);
            this.lstHandPlayer1.Name = "lstHandPlayer1";
            this.lstHandPlayer1.Size = new System.Drawing.Size(124, 308);
            this.lstHandPlayer1.TabIndex = 5;
            this.lstHandPlayer1.SelectedIndexChanged += new System.EventHandler(this.lstHandPlayer1_SelectedIndexChanged);
            // 
            // lblGoFish
            // 
            this.lblGoFish.BackColor = System.Drawing.Color.Orange;
            this.lblGoFish.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGoFish.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblGoFish.Location = new System.Drawing.Point(331, 110);
            this.lblGoFish.Name = "lblGoFish";
            this.lblGoFish.Size = new System.Drawing.Size(102, 52);
            this.lblGoFish.TabIndex = 8;
            this.lblGoFish.Text = "Go Fish";
            this.lblGoFish.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCountBooks
            // 
            this.lblCountBooks.BackColor = System.Drawing.Color.Transparent;
            this.lblCountBooks.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCountBooks.ForeColor = System.Drawing.Color.DarkOrange;
            this.lblCountBooks.Location = new System.Drawing.Point(558, 290);
            this.lblCountBooks.Name = "lblCountBooks";
            this.lblCountBooks.Size = new System.Drawing.Size(75, 47);
            this.lblCountBooks.TabIndex = 17;
            this.lblCountBooks.Text = "0";
            this.lblCountBooks.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblCountBooks.Click += new System.EventHandler(this.lblCountBooks_Click);
            // 
            // lblNumberOfBooks
            // 
            this.lblNumberOfBooks.BackColor = System.Drawing.Color.Transparent;
            this.lblNumberOfBooks.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumberOfBooks.ForeColor = System.Drawing.Color.DarkOrange;
            this.lblNumberOfBooks.Location = new System.Drawing.Point(437, 246);
            this.lblNumberOfBooks.Name = "lblNumberOfBooks";
            this.lblNumberOfBooks.Size = new System.Drawing.Size(332, 44);
            this.lblNumberOfBooks.TabIndex = 16;
            this.lblNumberOfBooks.Text = "Number Of Books";
            this.lblNumberOfBooks.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnLoadHand
            // 
            this.btnLoadHand.BackColor = System.Drawing.Color.Orange;
            this.btnLoadHand.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoadHand.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnLoadHand.Location = new System.Drawing.Point(280, 265);
            this.btnLoadHand.Name = "btnLoadHand";
            this.btnLoadHand.Size = new System.Drawing.Size(75, 59);
            this.btnLoadHand.TabIndex = 18;
            this.btnLoadHand.Text = "Load Hand";
            this.btnLoadHand.UseVisualStyleBackColor = false;
            this.btnLoadHand.Click += new System.EventHandler(this.btnLoadHand_Click);
            // 
            // Player1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 355);
            this.Controls.Add(this.btnLoadHand);
            this.Controls.Add(this.lblCountBooks);
            this.Controls.Add(this.lblNumberOfBooks);
            this.Controls.Add(this.lblGoFish);
            this.Controls.Add(this.lstHandPlayer1);
            this.Controls.Add(this.btnEndTurn1);
            this.Controls.Add(this.lblPlayerName1);
            this.Name = "Player1";
            this.Text = "Player1";
            this.Load += new System.EventHandler(this.Player1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPlayerName1;
        private System.Windows.Forms.Button btnEndTurn1;
        private System.Windows.Forms.ListBox lstHandPlayer1;
        private System.Windows.Forms.Label lblGoFish;
        private System.Windows.Forms.Label lblCountBooks;
        private System.Windows.Forms.Label lblNumberOfBooks;
        private System.Windows.Forms.Button btnLoadHand;
    }
}