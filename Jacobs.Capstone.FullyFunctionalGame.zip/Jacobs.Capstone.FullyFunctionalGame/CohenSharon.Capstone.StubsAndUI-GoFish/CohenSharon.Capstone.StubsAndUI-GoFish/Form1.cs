﻿using CohenSharon.Capstone.Design;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CohenSharon.Capstone.StubsAndUI_GoFish
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent(); // Initialize the form components
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void btnTwoPlayers_Click(object sender, EventArgs e)
        {
            AddPlayerNames playerNames = new AddPlayerNames(); // Create an instance of the AddPlayerNames form
            playerNames.ShowDialog(); // Display the AddPlayerNames form as a dialog
        }

        private void btnThreePlayers_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit(); // Exit the application
        }
    }
}
