﻿namespace CohenSharon.Capstone.StubsAndUI_GoFish
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnTwoPlayers = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblGoFish = new System.Windows.Forms.Label();
            this.lblDekelsGame = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnTwoPlayers
            // 
            this.btnTwoPlayers.BackColor = System.Drawing.Color.DarkOrange;
            this.btnTwoPlayers.ForeColor = System.Drawing.Color.Black;
            this.btnTwoPlayers.Location = new System.Drawing.Point(166, 289);
            this.btnTwoPlayers.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnTwoPlayers.Name = "btnTwoPlayers";
            this.btnTwoPlayers.Size = new System.Drawing.Size(101, 58);
            this.btnTwoPlayers.TabIndex = 1;
            this.btnTwoPlayers.Text = "Start";
            this.btnTwoPlayers.UseVisualStyleBackColor = false;
            this.btnTwoPlayers.Click += new System.EventHandler(this.btnTwoPlayers_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.DarkOrange;
            this.btnExit.Location = new System.Drawing.Point(534, 289);
            this.btnExit.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(101, 58);
            this.btnExit.TabIndex = 2;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblGoFish
            // 
            this.lblGoFish.BackColor = System.Drawing.Color.Transparent;
            this.lblGoFish.Font = new System.Drawing.Font("Microsoft Sans Serif", 50F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGoFish.ForeColor = System.Drawing.Color.Aqua;
            this.lblGoFish.Location = new System.Drawing.Point(203, 28);
            this.lblGoFish.Name = "lblGoFish";
            this.lblGoFish.Size = new System.Drawing.Size(341, 100);
            this.lblGoFish.TabIndex = 3;
            this.lblGoFish.Text = "Go Fish";
            this.lblGoFish.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblDekelsGame
            // 
            this.lblDekelsGame.BackColor = System.Drawing.Color.Transparent;
            this.lblDekelsGame.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDekelsGame.ForeColor = System.Drawing.Color.LightSkyBlue;
            this.lblDekelsGame.Location = new System.Drawing.Point(160, 138);
            this.lblDekelsGame.Name = "lblDekelsGame";
            this.lblDekelsGame.Size = new System.Drawing.Size(475, 100);
            this.lblDekelsGame.TabIndex = 4;
            this.lblDekelsGame.Text = "Welcome To Our Go Fish game.\r\nPlease Press Start To Play.\r\n";
            this.lblDekelsGame.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MidnightBlue;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 358);
            this.Controls.Add(this.lblDekelsGame);
            this.Controls.Add(this.lblGoFish);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnTwoPlayers);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnTwoPlayers;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblGoFish;
        private System.Windows.Forms.Label lblDekelsGame;
    }
}

