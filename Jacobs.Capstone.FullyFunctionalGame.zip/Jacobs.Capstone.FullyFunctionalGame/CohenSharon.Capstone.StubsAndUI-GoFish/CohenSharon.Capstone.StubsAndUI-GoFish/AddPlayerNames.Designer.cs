﻿namespace CohenSharon.Capstone.StubsAndUI_GoFish
{
    partial class AddPlayerNames
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddPlayerNames));
            this.lblPlayer1Name = new System.Windows.Forms.Label();
            this.txtPlayer1Name = new System.Windows.Forms.TextBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnStartGame = new System.Windows.Forms.Button();
            this.lblPlayer2Name = new System.Windows.Forms.Label();
            this.txtPlayer2Name = new System.Windows.Forms.TextBox();
            this.lblWinner = new System.Windows.Forms.Label();
            this.lblPlayAgain = new System.Windows.Forms.Label();
            this.btnDeal2 = new System.Windows.Forms.Button();
            this.grpPlayAgain = new System.Windows.Forms.GroupBox();
            this.grpPlayAgain.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblPlayer1Name
            // 
            this.lblPlayer1Name.AutoSize = true;
            this.lblPlayer1Name.Location = new System.Drawing.Point(32, 66);
            this.lblPlayer1Name.Name = "lblPlayer1Name";
            this.lblPlayer1Name.Size = new System.Drawing.Size(99, 16);
            this.lblPlayer1Name.TabIndex = 0;
            this.lblPlayer1Name.Text = "Player 1 Name:";
            // 
            // txtPlayer1Name
            // 
            this.txtPlayer1Name.Location = new System.Drawing.Point(199, 66);
            this.txtPlayer1Name.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtPlayer1Name.Name = "txtPlayer1Name";
            this.txtPlayer1Name.Size = new System.Drawing.Size(100, 22);
            this.txtPlayer1Name.TabIndex = 2;
            this.txtPlayer1Name.TextChanged += new System.EventHandler(this.txtPlayer1Name_TextChanged);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.Orange;
            this.btnExit.Location = new System.Drawing.Point(35, 340);
            this.btnExit.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(97, 47);
            this.btnExit.TabIndex = 4;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            // 
            // btnStartGame
            // 
            this.btnStartGame.BackColor = System.Drawing.Color.Orange;
            this.btnStartGame.Location = new System.Drawing.Point(312, 340);
            this.btnStartGame.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnStartGame.Name = "btnStartGame";
            this.btnStartGame.Size = new System.Drawing.Size(93, 47);
            this.btnStartGame.TabIndex = 5;
            this.btnStartGame.Text = "Start Game";
            this.btnStartGame.UseVisualStyleBackColor = false;
            this.btnStartGame.Click += new System.EventHandler(this.btnStartGame_Click);
            // 
            // lblPlayer2Name
            // 
            this.lblPlayer2Name.AutoSize = true;
            this.lblPlayer2Name.Location = new System.Drawing.Point(32, 153);
            this.lblPlayer2Name.Name = "lblPlayer2Name";
            this.lblPlayer2Name.Size = new System.Drawing.Size(99, 16);
            this.lblPlayer2Name.TabIndex = 6;
            this.lblPlayer2Name.Text = "Player 2 Name:";
            // 
            // txtPlayer2Name
            // 
            this.txtPlayer2Name.Location = new System.Drawing.Point(199, 150);
            this.txtPlayer2Name.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtPlayer2Name.Name = "txtPlayer2Name";
            this.txtPlayer2Name.Size = new System.Drawing.Size(100, 22);
            this.txtPlayer2Name.TabIndex = 7;
            // 
            // lblWinner
            // 
            this.lblWinner.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWinner.Location = new System.Drawing.Point(35, 18);
            this.lblWinner.Name = "lblWinner";
            this.lblWinner.Size = new System.Drawing.Size(267, 92);
            this.lblWinner.TabIndex = 12;
            this.lblWinner.Text = "(PlayerName) is the Winner";
            // 
            // lblPlayAgain
            // 
            this.lblPlayAgain.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlayAgain.Location = new System.Drawing.Point(44, 140);
            this.lblPlayAgain.Name = "lblPlayAgain";
            this.lblPlayAgain.Size = new System.Drawing.Size(237, 58);
            this.lblPlayAgain.TabIndex = 8;
            this.lblPlayAgain.Text = "Play Again?";
            // 
            // btnDeal2
            // 
            this.btnDeal2.BackColor = System.Drawing.Color.Orange;
            this.btnDeal2.Location = new System.Drawing.Point(109, 274);
            this.btnDeal2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnDeal2.Name = "btnDeal2";
            this.btnDeal2.Size = new System.Drawing.Size(84, 52);
            this.btnDeal2.TabIndex = 10;
            this.btnDeal2.Text = "Deal Again";
            this.btnDeal2.UseVisualStyleBackColor = false;
            this.btnDeal2.Click += new System.EventHandler(this.btnDeal2_Click);
            // 
            // grpPlayAgain
            // 
            this.grpPlayAgain.BackColor = System.Drawing.Color.LightSeaGreen;
            this.grpPlayAgain.Controls.Add(this.lblWinner);
            this.grpPlayAgain.Controls.Add(this.btnDeal2);
            this.grpPlayAgain.Controls.Add(this.lblPlayAgain);
            this.grpPlayAgain.Location = new System.Drawing.Point(467, 10);
            this.grpPlayAgain.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grpPlayAgain.Name = "grpPlayAgain";
            this.grpPlayAgain.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grpPlayAgain.Size = new System.Drawing.Size(315, 409);
            this.grpPlayAgain.TabIndex = 13;
            this.grpPlayAgain.TabStop = false;
            this.grpPlayAgain.Text = "Play Again?";
            this.grpPlayAgain.Enter += new System.EventHandler(this.grpPlayAgain_Enter);
            // 
            // AddPlayerNames
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.grpPlayAgain);
            this.Controls.Add(this.txtPlayer2Name);
            this.Controls.Add(this.lblPlayer2Name);
            this.Controls.Add(this.btnStartGame);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.txtPlayer1Name);
            this.Controls.Add(this.lblPlayer1Name);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "AddPlayerNames";
            this.Text = "AddPlayerNames";
            this.Load += new System.EventHandler(this.AddPlayerNames_Load);
            this.grpPlayAgain.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Label lblPlayer1Name;
        public System.Windows.Forms.TextBox txtPlayer1Name;
        private System.Windows.Forms.Button btnExit;
        public System.Windows.Forms.Button btnStartGame;
        public System.Windows.Forms.Label lblPlayer2Name;
        public System.Windows.Forms.TextBox txtPlayer2Name;
        private System.Windows.Forms.Label lblWinner;
        private System.Windows.Forms.Label lblPlayAgain;
        public System.Windows.Forms.Button btnDeal2;
        private System.Windows.Forms.GroupBox grpPlayAgain;
    }
}