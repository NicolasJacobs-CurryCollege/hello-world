﻿using CohenSharon.Capstone.Design;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace CohenSharon.Capstone.StubsAndUI_GoFish
{
    public partial class AddPlayerNames : Form
    {
        public int _startPlayer = 0;
        private Player _player0;
        private Player _player1;// Declare player0 as a private field
        private Deal _deal;

        public AddPlayerNames(String p0Name, String p1Name)
        {
            InitializeComponent();
            _deal = new Deal();//keep this Deal instantiation
            _player0 = new Player(0,_deal); // Initialize player0 in the constructor
            _player0.setPlayerName(p0Name); 
            _player1 = new Player(1, _deal);
            _player1.setPlayerName(p1Name);
        }

        public AddPlayerNames()
        {
            InitializeComponent();
            _deal = new Deal();//keep this Deal instantiation
            _player0 = new Player(0, _deal); // Initialize player0 in the constructor
            _player1 = new Player(1, _deal);
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void grpPlayAgain_Enter(object sender, EventArgs e)
        {
            Visible = false;
        }

        private void btnDeal2_Click(object sender, EventArgs e)
        {
           
        }

        public void startDealAt(int nuPlayers)
        {
            int firstPlayer = _startPlayer++; // Correct the spelling of "firstPlayer"
            if (_startPlayer == nuPlayers)
            {
                _startPlayer = 0;
            }
        }

        private void btnDeal3_Click(object sender, EventArgs e)
        {
            startDealAt(3);
        }

        public void txtPlayer1Name_TextChanged(object sender, EventArgs e)
        {
            _player0.playerName = txtPlayer1Name.Text; // Assign the text to player0's playerName property
        }

        private void AddPlayerNames_Load(object sender, EventArgs e)
        {

        }

        private void btnStartGame_Click(object sender, EventArgs e)
        {
            startDealAt(2);
            StartGame playGame = new StartGame(_deal, _player0, _player1);
            Player1 player0 = new Player1(_player0, _player1, _deal);
            player0.ShowDialog();
            //figure out which player is player 0
            //instatiate player 0, "zero"
            //instantiate player 1, "one"
            //make player 0 form appear - send reference to player 0 and player 1

        }
    }
}
