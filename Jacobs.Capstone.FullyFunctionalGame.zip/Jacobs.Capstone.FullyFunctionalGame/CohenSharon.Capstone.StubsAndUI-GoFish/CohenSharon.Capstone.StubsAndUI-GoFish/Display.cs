﻿namespace CohenSharon.Capstone.StubsAndUI_GoFish
{
    public class Display
    {
        public Display()
        {
            //instantiate the dealer
        }

        public void displayPlayer1Hand()
        {
            //display player 1 hand
        }

        public void displayPlayer2Hand()
        {
            //display player 2 hand
        }

        public void displayPlayer3Hand()
        {
            //display player 3 hand
        }

    }
}
