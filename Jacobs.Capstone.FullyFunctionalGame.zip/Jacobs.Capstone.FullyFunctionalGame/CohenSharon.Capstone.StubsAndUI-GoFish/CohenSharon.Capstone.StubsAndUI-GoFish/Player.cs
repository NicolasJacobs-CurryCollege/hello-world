﻿using System;

namespace CohenSharon.Capstone.Design
{
    public class Player
    {
        public String[] _myHand = new string[22]; // Array to store the player's hand
        private int _numBooks = 0; // Number of books the player has
        public String playerName; // Player's name

        public Player(int playerNum, Deal hand) // Constructor to initialize the player
        {
            populateHand(playerNum, hand); // Populate the player's hand
        }

        public int doYouHaveAny(string card) // Check how many cards of a specific type the player has
        {
            int count = 0;
            for (int n = 0; n < _myHand.Length; n++)
            {
                if (_myHand[n] == card)
                {
                    count++;
                }
            }
            return count;
        }

        public bool setPlayerName(String s) // Set the player's name
        {
            if (s != null && s.Length > 0)
            {
                playerName = s;
                return true;
            }
            return false;
        }

        public String getPlayerName() // Get the player's name
        {
            return playerName;
        }

        public bool set_myHand() // Set the player's hand
        {
            _myHand = createHand(); // Create a new hand for the player
            return true;
        }

        public String[] getHand() // Get the player's hand
        {
            return _myHand;
        }

        public bool setHandOneCard() // Set the player's hand with one card
        {
            _myHand = new string[1]; // Create a new hand with one card
            return true;
        }

        public String[] get_myHandOneCard() // Get the player's hand with one card
        {
            String[] oneCard_myHand = new string[1]; // Create an array to store the player's hand with one card
            oneCard_myHand[0] = _myHand[0]; // Assign the first card from the player's hand to the array
            return oneCard_myHand; // Return the array with one card
        }

        public String[] createHand() // Create a new hand for the player
        {
            String[] _myHand = new String[22]; // Create an array to store the player's hand with 22 cards
            for (int n = 0; n < _myHand.Length; n++) // Iterate through each element of the array
            {
                _myHand[n] = "Card " + (n + 1); // Assign a card value to each element of the array
            }
            return _myHand; // Return the created hand
        }

        public int getnumBooks() // Get the number of books the player has
        {
            return _numBooks; // Return the number of books the player has
        }

        public void removeBookFromHand(string card) // Remove a book from the player's hand
        {
            removeCardsFromHand(card); // Remove the cards of the book from the hand
            _numBooks++; // Increment the number of books
        }

        public bool findBookInHand() // Find a book in the player's hand
        {
            for (int n = 0; n < _myHand.Length; n++) // Iterate through each card in the player's hand
            {
                string card = _myHand[n]; // Get the current card
                if (countOccurrences(card) == 4) // If the card occurs 4 times in the hand, it forms a book
                {
                    removeBookFromHand(card); // Remove the book from the hand
                }
            }
            return true; // Return true indicating that a book was found and removed
        }

        public int countOccurrences(string card) // Count the occurrences of a card in the player's hand
        {
            int count = 0; // Initialize a count variable to 0
            for (int n = 0; n < _myHand.Length; n++) // Iterate through each card in the player's hand
            {
                if (_myHand[n] == card) // If the current card matches the specified card
                {
                    count++; // Increment the count
                }
            }
            return count; // Return the count of occurrences
        }

        private void removeCardsFromHand(string card) // Remove cards from the player's hand
        {
            string[] updatedHand = new string[22]; // Create a new array to store the updated hand
            int index = 0; // Initialize an index variable to 0
            for (int n = 0; n < _myHand.Length; n++) // Iterate through each card in the player's hand
            {
                if (_myHand[n] != card) // If the current card is not the specified card
                {
                    updatedHand[index] = _myHand[n]; // Add the current card to the updated hand
                    index++; // Increment the index
                }
            }
            _myHand = updatedHand; // Update the player's hand with the updated hand
        }

        public void addBookToCount() // Add a book to the player's count
        {
            _numBooks++; // Increment the number of books
        }

        public void populateHand(int n, Deal hand) // Populate the player's hand based on the player number
        {
            if (n == 0) // If the player number is 0
            {
                _myHand = hand.getPlayer0Hand(); // Get the hand of player 0 from the Deal object
            }
            else // If the player number is not 0
            {
                _myHand = hand.getPlayer1Hand(); // Get the hand of player 1 from the Deal object
            }
        }

        public void orderHand() // Order the player's hand
        {
            String[] orderdString = new string[_myHand.Length]; // Create a new array to store the ordered hand
            String item = ""; // Initialize an item variable to store the current card

            for (int n = 0; n < _myHand.Length - 1; n++) // Iterate through each card in the player's hand
            {
                for (int p = 0; p < 13; p++) // Iterate through each possible card value
                {
                    switch (p) // Check the current card value
                    {
                        case 0:
                            item = "ace"; // If the card value is 0, set the item to "ace"
                            break;
                        case 10:
                            item = "jack"; // If the card value is 10, set the item to "jack"
                            break;
                        case 11:
                            item = "queen"; // If the card value is 11, set the item to "queen"
                            break;
                        case 13:
                            item = "king"; // If the card value is 13, set the item to "king"
                            break;
                        default:
                            item = _myHand[p].ToLower(); // For other card values, set the item to the lowercase value of the card
                            break;
                    }
                }
                for (int q = 0; q < _myHand.Length; q++) // Iterate through each card in the player's hand
                {
                    if (_myHand[q] == item) // If the current card matches the item
                    {
                        orderdString[n] = item; // Add the card to the ordered hand
                        n++; // Increment the index
                    }
                }
            }
        }

        public void askAgain(string card) // Ask the other player for a card
        {
            bool found = false; // Initialize a found variable to false
            int n = 0; // Initialize an index variable to 0
            while (!found && n < _myHand.Length) // Iterate through each card in the player's hand until the card is found or the end of the hand is reached
            {
                if (_myHand[n] == card) // If the current card matches the specified card
                {
                    found = true; // Set found to true
                }
                else // If the current card does not match the specified card
                {
                    n++; // Increment the index
                }
            }

            if (found) // If the card is found in the hand
            {
                for (int m = 0; m < _myHand.Length; m++) // Iterate through each card in the player's hand
                {
                    if (_myHand[m] == card) // If the current card matches the specified card
                    {
                        _myHand[m] = null; // Remove the card from the hand by setting it to null
                    }
                }

                orderHand(); // Order the player's hand
            }
            else // If the card is not found in the hand
            {
                // TODO: Implement the logic to tell the other player to go fish
            }
        }

        public bool checkForBooks(string[] hand) // Check if the player has formed a book
        {
            int count = 0; // Initialize a count variable to 0
            for (int n = 0; n < hand.Length - 1; n++) // Iterate through each card in the hand
            {
                for (int m = n + 1; m < hand.Length; m++) // Iterate through each card after the current card
                {
                    if (hand[n] == hand[m]) // If the current card matches the other card
                    {
                        count++; // Increment the count
                    }
                }
            }
            if (count == 6) // Assuming a book consists of 4 cards, check if the count is 6
            {
                return true; // Return true if a book is formed
            }
            return false; // Return false if a book is not formed
        }

        public String[] addCardToHand(string card, int numTimes) // Add a card to the player's hand
        {
            for (int n = 0, p = 0; n < _myHand.Length; n++) // Iterate through each card in the player's hand
            {
                if (_myHand[n] != null) // If the current card is not null, continue to the next card
                    continue;

                if (p < numTimes) // If the number of added cards is less than the specified number of times
                {
                    _myHand[n] = card; // Add the card to the player's hand
                    p++; // Increment the count of added cards
                }
            }
            orderHand(); // Order the player's hand
            return _myHand; // Return the updated hand
        }

        public String[] removeCardFromHand(string card) // Remove a card from the player's hand
        {
            for (int n = 0; n < _myHand.Length; n++) // Iterate through each card in the player's hand
            {
                if (_myHand[n].StartsWith(card)) // If the current card starts with the specified card
                {
                    _myHand[n] = null; // Remove the card from the hand by setting it to null
                }
            }
            orderHand(); // Order the player's hand
            return _myHand; // Return the updated hand
        }

        public String goFish(String[] askingPlayerHand, Deal theCard) // Perform the "Go Fish" action
        {
            string card = theCard.goFishCard(); // Get a card from the deck

            for (int n = 0; n < askingPlayerHand.Length; n++) // Iterate through each card in the asking player's hand
            {
                if (askingPlayerHand[n] == null) // If the current card is null
                {
                    askingPlayerHand[n] = card; // Add the card to the asking player's hand
                    break; // Exit the loop
                }
            }

            return card; // Return the card that was added to the hand
        }

        public bool checkIfGoFishCardIsDrawnFromDeck(string askedCard, string goFishCard) // Check if the "Go Fish" card is drawn from the deck
        {
            if (askedCard.StartsWith(goFishCard)) // Check if the chosen card is in the deck
            {
                return true; // Return true if the card is drawn from the deck
            }
            else
            {
                return false; // Return false if the card is not drawn from the deck
            }
        }
    }
}
